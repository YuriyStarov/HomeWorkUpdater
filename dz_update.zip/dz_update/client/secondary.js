'use strict';

const newVersion = document.getElementById ('newVersion');
const updateInfo = document.getElementById ('updateInfo');

window.forAll.addUpdateMSGHandler((event, data) => {
  updateMSG.textContent = data;
});

window.forAll.addVersionMSGHandler((event, data) => {
  newVersion.textContent = data;
});
