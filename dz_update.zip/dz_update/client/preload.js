'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('forAll', {
  addUpdateMSGHandler: (callback) => ipcRenderer.on('update', callback),
  addVersionMSGHandler: (callback) => ipcRenderer.on('version', callback)
});
