'use strict';

const { app, BrowserWindow, ipcMain } = require ('electron');
const { join } = require ('path');
const { autoUpdater, appUpdater } = require ('electron-updater');
const { channel } = require('diagnostics_channel');

autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = true;

let winPlus;

const messageToScript = (channel, ...message) => {
    winPlus.webContents.send (channel, message);
}

app.on ('ready', () => {

        allListener ();

        winPlus = new BrowserWindow({
        autoHideMenuBar: true,
        backgroundColor: 'olive',
        width: 600,
        height: 740,
        webPreferences: { nodeIntegration: true, 
            contextIsolation: false, 
            preload: join(__dirname, "./client/preload.js")
        } 
    });

winPlus.loadFile (join(__dirname, "./client/first.html"));

winPlus.on("ready-to-show",() => {
    winPlus.show();
    messageToScript ('version',app.getVersion());
    messageToScript ('update','checking for update');
    autoUpdater.checkForUpdates ();
    })
});



function allListener () {

    autoUpdater.on ('update-available', (info) => {
        messageToScript ('update','update-available',info);
        const path = autoUpdater.downloadUpdate ();
        messageToScript ('update',path);
    });

    autoUpdater.on ('update-not-available', (info) => {
        messageToScript ('update','update-not-available',info);
    });

    autoUpdater.on ('update-downloaded', (info) => {
        messageToScript ('update','update-downloaded',info);
    });

    autoUpdater.on ('error', (info) => {
        messageToScript ('update','error',info);
    });

};


